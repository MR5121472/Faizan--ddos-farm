
import subprocess

def launch_botnet():
    print("\n[+] Spawning simulated bots...\n")
    for _ in range(3):
        subprocess.Popen(["python", "main.py"])
