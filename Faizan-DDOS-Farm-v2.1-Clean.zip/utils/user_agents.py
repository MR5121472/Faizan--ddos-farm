
import random

def get_random_agent():
    agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Mozilla/5.0 (Linux; Android 10)",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 14_2 like Mac OS X)",
        "Mozilla/5.0 (X11; Ubuntu; Linux x86_64)"
    ]
    return random.choice(agents)
