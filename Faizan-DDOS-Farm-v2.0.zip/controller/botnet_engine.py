
import subprocess

def launch_botnet():
    print("\n[+] Launching Faizan BotNet...\n")
    bot_scripts = ["main.py", "main.py", "main.py"]
    for bot in bot_scripts:
        subprocess.Popen(["python", bot])
