
import random

def get_proxy():
    with open("proxies.txt", "r") as file:
        proxies = file.read().splitlines()
    return random.choice(proxies)
